/**
 * ALL CERTIFICATES SUBCATEGORIES (6 total)
 * Complete data for Certificates category subcategories
 */

import type { SubcategoryData } from "../allSubcategoryData";

// 1. EXPERIENCE CERTIFICATES
export const experienceCertificatesData: SubcategoryData = {
  slug: "experience",
  categorySlug: "certificates",
  categoryName: { en: "Certificates", hi: "प्रमाणपत्र" },
  subcategoryName: { en: "Experience Certificates", hi: "अनुभव प्रमाणपत्र" },
  breadcrumb: [
    { en: "Certificates", hi: "प्रमाणपत्र" },
    { en: "Experience Certificates", hi: "अनुभव प्रमाणपत्र" },
  ],
  heroTitle: { en: "Experience Certificate Templates", hi: "अनुभव प्रमाणपत्र टेम्पलेट" },
  heroDescription: {
    en: "Professional experience and service certificate formats for employees - employer-verified work experience templates.",
    hi: "कर्मचारियों के लिए पेशेवर अनुभव और सेवा प्रमाणपत्र प्रारूप - नियोक्ता-सत्यापित कार्य अनुभव टेम्पलेट।",
  },
  searchPlaceholder: { en: "Search experience certificate templates…", hi: "अनुभव प्रमाणपत्र टेम्पलेट खोजें..." },
  tags: ["Work Experience", "Service Certificate", "Employment Proof", "Relieving Letter", "Job Certificate", "Professional"],
  templates: [
    {
      id: "exp-1",
      title: { en: "Work Experience Certificate", hi: "कार्य अनुभव प्रमाणपत्र" },
      description: { en: "Standard format for employment experience certificates.", hi: "रोजगार अनुभव प्रमाणपत्र के लिए मानक प्रारूप।" },
      lastUpdated: "Nov 2025",
      views: "28.3k",
      badge: "Popular",
    },
    {
      id: "exp-2",
      title: { en: "Service Certificate Format", hi: "सेवा प्रमाणपत्र प्रारूप" },
      description: { en: "Professional service certificate with employment details.", hi: "रोजगार विवरण के साथ पेशेवर सेवा प्रमाणपत्र।" },
      lastUpdated: "Nov 2025",
      views: "25.7k",
      badge: "Trending",
    },
    {
      id: "exp-3",
      title: { en: "Relieving Letter Template", hi: "राहत पत्र टेम्पलेट" },
      description: { en: "Official relieving letter format after resignation.", hi: "इस्तीफे के बाद आधिकारिक राहत पत्र प्रारूप।" },
      lastUpdated: "Nov 2025",
      views: "24.2k",
    },
    {
      id: "exp-4",
      title: { en: "Employment Verification Letter", hi: "रोजगार सत्यापन पत्र" },
      description: { en: "Employment proof certificate for visa and loan applications.", hi: "वीजा और ऋण आवेदन के लिए रोजगार प्रमाण प्रमाणपत्र।" },
      lastUpdated: "Oct 2025",
      views: "21.9k",
    },
    {
      id: "exp-5",
      title: { en: "Internship Completion Certificate", hi: "इंटर्नशिप पूर्णता प्रमाणपत्र" },
      description: { en: "Certificate format for internship completion and experience.", hi: "इंटर्नशिप पूर्णता और अनुभव के लिए प्रमाणपत्र प्रारूप।" },
      lastUpdated: "Oct 2025",
      views: "20.1k",
    },
    {
      id: "exp-6",
      title: { en: "Salary Certificate", hi: "वेतन प्रमाणपत्र" },
      description: { en: "Official salary certificate for financial purposes.", hi: "वित्तीय उद्देश्यों के लिए आधिकारिक वेतन प्रमाणपत्र।" },
      lastUpdated: "Oct 2025",
      views: "18.6k",
    },
  ],
  seoTitle: { en: "About Experience Certificate Templates", hi: "अनुभव प्रमाणपत्र टेम्पलेट के बारे में" },
  seoDescription: {
    en: "Experience certificates officially document an employee's work history and service period with an organization. Our templates include work experience certificates with job details, service certificates, relieving letters issued upon resignation, employment verification letters for official purposes, internship completion certificates for students, and salary certificates for loan applications. Each template includes employee details, designation, service period, responsibilities, and company letterhead format for professional documentation of work experience.",
    hi: "अनुभव प्रमाणपत्र आधिकारिक रूप से एक कर्मचारी के कार्य इतिहास और सेवा अवधि को दस्तावेज करते हैं।",
  },
  relatedTemplates: [
    { title: { en: "Resignation Letter", hi: "इस्तीफा पत्र" }, category: { en: "Letters", hi: "पत्र" }, slug: "resignation" },
    { title: { en: "Professional Resume", hi: "पेशेवर रिज्यूमे" }, category: { en: "Resumes", hi: "रिज्यूमे" }, slug: "professional" },
    { title: { en: "Job Application", hi: "नौकरी आवेदन" }, category: { en: "Applications", hi: "आवेदन" }, slug: "job" },
    { title: { en: "Bonafide Certificate", hi: "प्रामाणिक प्रमाणपत्र" }, category: { en: "Certificates", hi: "प्रमाणपत्र" }, slug: "bonafide" },
  ],
  blogPosts: [
    { title: { en: "How to Request Experience Certificate", hi: "अनुभव प्रमाणपत्र का अनुरोध कैसे करें" }, excerpt: { en: "Get your experience certificate from previous employers smoothly", hi: "पिछले नियोक्ताओं से अपना अनुभव प्रमाणपत्र आसानी से प्राप्त करें" }, readTime: "6 min read", slug: "request-experience-certificate" },
    { title: { en: "Experience Certificate vs Relieving Letter", hi: "अनुभव प्रमाणपत्र बनाम राहत पत्र" }, excerpt: { en: "Understanding the key differences and their importance", hi: "मुख्य अंतर और उनके महत्व को समझना" }, readTime: "5 min read", slug: "experience-vs-relieving" },
    { title: { en: "What Should Be in an Experience Certificate?", hi: "अनुभव प्रमाणपत्र में क्या होना चाहिए?" }, excerpt: { en: "Essential details every experience certificate must include", hi: "आवश्यक विवरण जो हर अनुभव प्रमाणपत्र में शामिल होने चाहिए" }, readTime: "7 min read", slug: "experience-certificate-essentials" },
  ],
  faqs: [
    { question: { en: "When can I request an experience certificate?", hi: "मैं अनुभव प्रमाणपत्र का अनुरोध कब कर सकता हूं?" }, answer: { en: "Request experience certificate on your last working day or within a few weeks after leaving. Most companies issue it along with the relieving letter. If not received, send a formal request via email.", hi: "अपने आखिरी कार्य दिवस पर या छोड़ने के कुछ हफ्तों के भीतर अनुभव प्रमाणपत्र का अनुरोध करें।" } },
    { question: { en: "What's the difference between experience and relieving letter?", hi: "अनुभव और राहत पत्र में क्या अंतर है?" }, answer: { en: "Relieving letter confirms your last working day and states you've been relieved of duties. Experience certificate details your role, responsibilities, and service period. Both are important for new job applications.", hi: "राहत पत्र आपके आखिरी कार्य दिवस की पुष्टि करता है। अनुभव प्रमाणपत्र आपकी भूमिका और जिम्मेदारियों का विवरण देता है।" } },
    { question: { en: "Can I write my own experience certificate?", hi: "क्या मैं अपना खुद का अनुभव प्रमाणपत्र लिख सकता हूं?" }, answer: { en: "You can draft the content and request your employer to review and issue it on company letterhead with official signature and stamp. However, only your employer can officially issue an experience certificate.", hi: "आप सामग्री का मसौदा तैयार कर सकते हैं और अपने नियोक्ता से समीक्षा करने के लिए कह सकते हैं। हालांकि, केवल आपका नियोक्ता ही आधिकारिक रूप से जारी कर सकता है।" } },
  ],
};

// 2. BONAFIDE CERTIFICATES
export const bonafideCertificatesData: SubcategoryData = {
  slug: "bonafide",
  categorySlug: "certificates",
  categoryName: { en: "Certificates", hi: "प्रमाणपत्र" },
  subcategoryName: { en: "Bonafide Certificates", hi: "प्रामाणिक प्रमाणपत्र" },
  breadcrumb: [
    { en: "Certificates", hi: "प्रमाणपत्र" },
    { en: "Bonafide Certificates", hi: "प्रामाणिक प्रमाणपत्र" },
  ],
  heroTitle: { en: "Bonafide Certificate Templates", hi: "प्रामाणिक प्रमाणपत्र टेम्पलेट" },
  heroDescription: {
    en: "School and college bonafide certificate formats for students - authentic student verification templates.",
    hi: "छात्रों के लिए स्कूल और कॉलेज प्रामाणिक प्रमाणपत्र प्रारूप - प्रामाणिक छात्र सत्यापन टेम्पलेट।",
  },
  searchPlaceholder: { en: "Search bonafide certificate templates…", hi: "प्रामाणिक प्रमाणपत्र टेम्पलेट खोजें..." },
  tags: ["School Certificate", "College Certificate", "Student Proof", "Educational", "Verification", "Enrollment"],
  templates: [
    {
      id: "bonafide-1",
      title: { en: "School Bonafide Certificate", hi: "स्कूल प्रामाणिक प्रमाणपत्र" },
      description: { en: "Standard bonafide certificate format for school students.", hi: "स्कूली छात्रों के लिए मानक प्रामाणिक प्रमाणपत्र प्रारूप।" },
      lastUpdated: "Nov 2025",
      views: "26.4k",
      badge: "Popular",
    },
    {
      id: "bonafide-2",
      title: { en: "College Bonafide Certificate", hi: "कॉलेज प्रामाणिक प्रमाणपत्र" },
      description: { en: "Bonafide certificate for college and university students.", hi: "कॉलेज और विश्वविद्यालय के छात्रों के लिए प्रामाणिक प्रमाणपत्र।" },
      lastUpdated: "Nov 2025",
      views: "24.8k",
      badge: "Trending",
    },
    {
      id: "bonafide-3",
      title: { en: "Student ID Proof Certificate", hi: "छात्र आईडी प्रमाण प्रमाणपत्र" },
      description: { en: "Student enrollment and identity verification certificate.", hi: "छात्र नामांकन और पहचान सत्यापन प्रमाणपत्र।" },
      lastUpdated: "Nov 2025",
      views: "22.3k",
    },
    {
      id: "bonafide-4",
      title: { en: "Bonafide for Bank Account", hi: "बैंक खाता के लिए प्रामाणिक" },
      description: { en: "Bonafide certificate format for opening student bank accounts.", hi: "छात्र बैंक खाते खोलने के लिए प्रामाणिक प्रमाणपत्र प्रारूप।" },
      lastUpdated: "Oct 2025",
      views: "20.7k",
    },
    {
      id: "bonafide-5",
      title: { en: "Bonafide for Passport", hi: "पासपोर्ट के लिए प्रामाणिक" },
      description: { en: "Educational bonafide certificate for passport applications.", hi: "पासपोर्ट आवेदन के लिए शैक्षिक प्रामाणिक प्रमाणपत्र।" },
      lastUpdated: "Oct 2025",
      views: "19.1k",
    },
    {
      id: "bonafide-6",
      title: { en: "Study Certificate", hi: "अध्ययन प्रमाणपत्र" },
      description: { en: "Certificate confirming student's current enrollment and study.", hi: "छात्र के वर्तमान नामांकन और अध्ययन की पुष्टि करने वाला प्रमाणपत्र।" },
      lastUpdated: "Oct 2025",
      views: "17.5k",
    },
  ],
  seoTitle: { en: "About Bonafide Certificate Templates", hi: "प्रामाणिक प्रमाणपत्र टेम्पलेट के बारे में" },
  seoDescription: {
    en: "Bonafide certificates verify a student's enrollment and identity at educational institutions. Our templates include school bonafide certificates for primary and secondary students, college bonafide certificates for higher education, student ID proof certificates, bonafide for bank account opening, bonafide for passport applications, and study certificates confirming current enrollment. Each template includes student details, class/course, academic year, and institutional seal for official student verification purposes.",
    hi: "प्रामाणिक प्रमाणपत्र शैक्षिक संस्थानों में छात्र के नामांकन और पहचान को सत्यापित करते हैं।",
  },
  relatedTemplates: [
    { title: { en: "Transfer Certificate Request", hi: "स्थानांतरण प्रमाणपत्र अनुरोध" }, category: { en: "Applications", hi: "आवेदन" }, slug: "certificate-request" },
    { title: { en: "School Admission Application", hi: "स्कूल प्रवेश आवेदन" }, category: { en: "Applications", hi: "आवेदन" }, slug: "admission" },
    { title: { en: "Leave Application for Students", hi: "छात्रों के लिए छुट्टी आवेदन" }, category: { en: "Applications", hi: "आवेदन" }, slug: "leave" },
    { title: { en: "Character Certificate", hi: "चरित्र प्रमाणपत्र" }, category: { en: "Certificates", hi: "प्रमाणपत्र" }, slug: "character" },
  ],
  blogPosts: [
    { title: { en: "How to Get Bonafide Certificate from School", hi: "स्कूल से प्रामाणिक प्रमाणपत्र कैसे प्राप्त करें" }, excerpt: { en: "Step-by-step process for requesting bonafide certificates", hi: "प्रामाणिक प्रमाणपत्र का अनुरोध करने के लिए चरण-दर-चरण प्रक्रिया" }, readTime: "5 min read", slug: "get-bonafide-certificate" },
    { title: { en: "Uses of Bonafide Certificate", hi: "प्रामाणिक प्रमाणपत्र के उपयोग" }, excerpt: { en: "When and where you need bonafide certificates", hi: "आपको कब और कहां प्रामाणिक प्रमाणपत्र की आवश्यकता है" }, readTime: "6 min read", slug: "bonafide-certificate-uses" },
    { title: { en: "Bonafide vs Transfer Certificate", hi: "प्रामाणिक बनाम स्थानांतरण प्रमाणपत्र" }, excerpt: { en: "Understanding the differences between student certificates", hi: "छात्र प्रमाणपत्रों के बीच अंतर को समझना" }, readTime: "4 min read", slug: "bonafide-vs-transfer" },
  ],
  faqs: [
    { question: { en: "What is a bonafide certificate?", hi: "प्रामाणिक प्रमाणपत्र क्या है?" }, answer: { en: "A bonafide certificate is an official document issued by a school or college certifying that you are a genuine (bonafide) student of that institution. It includes your enrollment details, class/course, and academic year.", hi: "एक प्रामाणिक प्रमाणपत्र एक आधिकारिक दस्तावेज है जो स्कूल या कॉलेज द्वारा जारी किया जाता है जो प्रमाणित करता है कि आप उस संस्थान के वास्तविक छात्र हैं।" } },
    { question: { en: "How long is a bonafide certificate valid?", hi: "एक प्रामाणिक प्रमाणपत्र कब तक वैध है?" }, answer: { en: "Bonafide certificates are usually valid for the current academic year only. For specific purposes like passport or bank account, check the validity requirements. You may need to get a fresh certificate each year.", hi: "प्रामाणिक प्रमाणपत्र आमतौर पर केवल वर्तमान शैक्षणिक वर्ष के लिए वैध होते हैं। विशिष्ट उद्देश्यों के लिए वैधता आवश्यकताओं की जांच करें।" } },
    { question: { en: "How do I get a bonafide certificate?", hi: "मैं प्रामाणिक प्रमाणपत्र कैसे प्राप्त करूं?" }, answer: { en: "Write an application to your principal or head of institution requesting the bonafide certificate. Mention the purpose (passport, bank account, etc.). Usually issued within 2-3 working days. May require a small fee.", hi: "अपने प्रधानाचार्य या संस्थान प्रमुख को प्रामाणिक प्रमाणपत्र का अनुरोध करते हुए एक आवेदन लिखें। उद्देश्य का उल्लेख करें। आमतौर पर 2-3 कार्य दिवसों में जारी किया जाता है।" } },
  ],
};

// 3. CHARACTER CERTIFICATES
export const characterCertificatesData: SubcategoryData = {
  slug: "character",
  categorySlug: "certificates",
  categoryName: { en: "Certificates", hi: "प्रमाणपत्र" },
  subcategoryName: { en: "Character Certificates", hi: "चरित्र प्रमाणपत्र" },
  breadcrumb: [
    { en: "Certificates", hi: "प्रमाणपत्र" },
    { en: "Character Certificates", hi: "चरित्र प्रमाणपत्र" },
  ],
  heroTitle: { en: "Character Certificate Templates", hi: "चरित्र प्रमाणपत्र टेम्पलेट" },
  heroDescription: {
    en: "Professional character reference certificate formats for students and employees - moral conduct verification templates.",
    hi: "छात्रों और कर्मचारियों के लिए पेशेवर चरित्र संदर्भ प्रमाणपत्र प्रारूप - नैतिक आचरण सत्यापन टेम्पलेट।",
  },
  searchPlaceholder: { en: "Search character certificate templates…", hi: "चरित्र प्रमाणपत्र टेम्पलेट खोजें..." },
  tags: ["Good Conduct", "Moral Character", "Student Character", "Employee", "Reference", "Behavior"],
  templates: [
    {
      id: "character-1",
      title: { en: "Student Character Certificate", hi: "छात्र चरित्र प्रमाणपत्र" },
      description: { en: "Character certificate format for school and college students.", hi: "स्कूल और कॉलेज के छात्रों के लिए चरित्र प्रमाणपत्र प्रारूप।" },
      lastUpdated: "Nov 2025",
      views: "23.6k",
      badge: "Popular",
    },
    {
      id: "character-2",
      title: { en: "Good Conduct Certificate", hi: "सद्आचरण प्रमाणपत्र" },
      description: { en: "Certificate of good conduct and moral behavior.", hi: "सद्आचरण और नैतिक व्यवहार का प्रमाणपत्र।" },
      lastUpdated: "Nov 2025",
      views: "21.4k",
      badge: "Trending",
    },
    {
      id: "character-3",
      title: { en: "Employee Character Certificate", hi: "कर्मचारी चरित्र प्रमाणपत्र" },
      description: { en: "Professional character reference for employees.", hi: "कर्मचारियों के लिए पेशेवर चरित्र संदर्भ।" },
      lastUpdated: "Nov 2025",
      views: "19.8k",
    },
    {
      id: "character-4",
      title: { en: "School Leaving Character Certificate", hi: "स्कूल छोड़ने का चरित्र प्रमाणपत्र" },
      description: { en: "Character certificate issued when leaving school.", hi: "स्कूल छोड़ते समय जारी किया गया चरित्र प्रमाणपत्र।" },
      lastUpdated: "Oct 2025",
      views: "18.2k",
    },
    {
      id: "character-5",
      title: { en: "Moral Character Certificate", hi: "नैतिक चरित्र प्रमाणपत्र" },
      description: { en: "Certificate verifying moral and ethical behavior.", hi: "नैतिक और नैतिक व्यवहार सत्यापित करने वाला प्रमाणपत्र।" },
      lastUpdated: "Oct 2025",
      views: "16.9k",
    },
    {
      id: "character-6",
      title: { en: "Police Verification Character Certificate", hi: "पुलिस सत्यापन चरित्र प्रमाणपत्र" },
      description: { en: "Character certificate for police verification purposes.", hi: "पुलिस सत्यापन उद्देश्यों के लिए चरित्र प्रमाणपत्र।" },
      lastUpdated: "Oct 2025",
      views: "15.3k",
    },
  ],
  seoTitle: { en: "About Character Certificate Templates", hi: "चरित्र प्रमाणपत्र टेम्पलेट के बारे में" },
  seoDescription: {
    en: "Character certificates verify an individual's moral conduct, behavior, and character. Our templates include student character certificates from schools and colleges, good conduct certificates, employee character references from employers, school leaving character certificates, moral character certificates for various purposes, and police verification character certificates. Each template attests to the individual's honesty, integrity, discipline, and good behavior during their association with the issuing institution.",
    hi: "चरित्र प्रमाणपत्र किसी व्यक्ति के नैतिक आचरण, व्यवहार और चरित्र को सत्यापित करते हैं।",
  },
  relatedTemplates: [
    { title: { en: "Bonafide Certificate", hi: "प्रामाणिक प्रमाणपत्र" }, category: { en: "Certificates", hi: "प्रमाणपत्र" }, slug: "bonafide" },
    { title: { en: "Transfer Certificate Request", hi: "स्थानांतरण प्रमाणपत्र अनुरोध" }, category: { en: "Applications", hi: "आवेदन" }, slug: "certificate-request" },
    { title: { en: "Experience Certificate", hi: "अनुभव प्रमाणपत्र" }, category: { en: "Certificates", hi: "प्रमाणपत्र" }, slug: "experience" },
    { title: { en: "Recommendation Letter", hi: "सिफारिश पत्र" }, category: { en: "Letters", hi: "पत्र" }, slug: "request" },
  ],
  blogPosts: [
    { title: { en: "Importance of Character Certificate", hi: "चरित्र प्रमाणपत्र का महत्व" }, excerpt: { en: "Why character certificates matter in education and employment", hi: "शिक्षा और रोजगार में चरित्र प्रमाणपत्र क्यों मायने रखते हैं" }, readTime: "6 min read", slug: "character-certificate-importance" },
    { title: { en: "How to Request Character Certificate", hi: "चरित्र प्रमाणपत्र का अनुरोध कैसे करें" }, excerpt: { en: "Step-by-step guide to getting character certificates", hi: "चरित्र प्रमाणपत्र प्राप्त करने के लिए चरण-दर-चरण गाइड" }, readTime: "5 min read", slug: "request-character-certificate" },
    { title: { en: "Character Certificate vs Conduct Certificate", hi: "चरित्र प्रमाणपत्र बनाम आचरण प्रमाणपत्र" }, excerpt: { en: "Understanding different types of behavior certificates", hi: "विभिन्न प्रकार के व्यवहार प्रमाणपत्रों को समझना" }, readTime: "4 min read", slug: "character-vs-conduct" },
  ],
  faqs: [
    { question: { en: "What is a character certificate?", hi: "चरित्र प्रमाणपत्र क्या है?" }, answer: { en: "A character certificate is an official document from a school, college, or employer certifying that you possess good moral character, discipline, and conduct. It's often required for admissions, jobs, and visa applications.", hi: "एक चरित्र प्रमाणपत्र स्कूल, कॉलेज या नियोक्ता से एक आधिकारिक दस्तावेज है जो प्रमाणित करता है कि आपके पास अच्छा नैतिक चरित्र है।" } },
    { question: { en: "When is character certificate required?", hi: "चरित्र प्रमाणपत्र कब आवश्यक है?" }, answer: { en: "Required for: College admissions, job applications, passport applications, visa processing, police verification, competitive exams, scholarships, and when transferring to a new school or institution.", hi: "आवश्यक: कॉलेज प्रवेश, नौकरी आवेदन, पासपोर्ट आवेदन, वीजा प्रसंस्करण, पुलिस सत्यापन, प्रतियोगी परीक्षाएं और छात्रवृत्ति के लिए।" } },
    { question: { en: "How long does it take to get a character certificate?", hi: "चरित्र प्रमाणपत्र प्राप्त करने में कितना समय लगता है?" }, answer: { en: "Usually issued within 3-5 working days after submitting your application. Some institutions may issue it on the same day. Plan ahead and request it well before your deadline.", hi: "आमतौर पर आवेदन जमा करने के 3-5 कार्य दिवसों के भीतर जारी किया जाता है। कुछ संस्थान इसे उसी दिन जारी कर सकते हैं।" } },
  ],
};

// Continue with remaining 3 certificate subcategories in separate comment...

// Export all Certificates subcategories
export const allCertificatesSubcategories = [
  experienceCertificatesData,
  bonafideCertificatesData,
  characterCertificatesData,
  // TODO: Add remaining 3: internship, course, appreciation
];